PETASA — Galeri Benda Langit (Revisi)
Unggah ZIP ini ke Netlify Drop atau ekstrak lalu unggah folder yang berisi index.html.
Semua gambar sudah tertanam langsung dalam index.html. Tidak memerlukan folder gambar.
Konten bersumber dari referensi buku yang diberikan dan sumber NASA Science yang ditautkan pada setiap kartu.
